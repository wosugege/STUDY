package com.cvte.king.robot.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cvte.king.robot.pojo.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * 文件描述
 *
 * @author AKing
 * @date 2020年07月30日 16:03
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
