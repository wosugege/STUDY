package com.cvte.king.robot.pojo;

import java.io.Serializable;

/**
 * 文件描述
 *
 * @author AKing
 * @date 2020年07月31日 14:50
 */
public class OtherInfo implements Serializable {
    private Integer id;
    private String info;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + id +
                ", info='" + info + '\'' +
                '}';
    }
}
