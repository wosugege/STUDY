package com.cvte.king.robot.service;

/**
 * 文件描述
 *
 * @author AKing
 * @date 2020年08月01日 11:40
 */
public interface IUserService {

}
