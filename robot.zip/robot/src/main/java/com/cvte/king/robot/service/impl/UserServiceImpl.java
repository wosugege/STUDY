package com.cvte.king.robot.service.impl;

import com.cvte.king.robot.service.IUserService;

/**
 * 文件描述
 *
 * @author AKing
 * @date 2020年08月01日 11:41
 */
public class UserServiceImpl implements IUserService {
}
