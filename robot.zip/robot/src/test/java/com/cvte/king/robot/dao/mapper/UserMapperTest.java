package com.cvte.king.robot.dao.mapper;

import com.cvte.king.robot.pojo.OtherInfo;
import com.cvte.king.robot.pojo.User;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.List;

/**
 * 文件描述
 *
 * @author AKing
 * @date 2020年07月30日 16:05
 */
@SpringBootTest
public class UserMapperTest {
    @Resource
    UserMapper userMapper;

    @Test
    public void testSelect() {
        OtherInfo otherInfo = new OtherInfo();
        otherInfo.setId(1);
        otherInfo.setInfo("其他信息");
        User user = new User();
//        user.setId(106L);
        user.setAge(24);
        user.setName("小诸葛");
        user.setEmail("360916@qq.com");
        user.setOtherInfo(otherInfo);
        int insert = userMapper.insert(user);
        System.out.println(insert == 1);
        User user1 = userMapper.selectById(101L);
        System.out.println(user1);
        System.out.println(user1.getOtherInfo());
        System.out.println(("----- selectAll method test ------"));
        List<User> userList = userMapper.selectList(null);
        Assert.assertEquals(5, userList.size());
        userList.forEach(System.out::println);
    }
}
